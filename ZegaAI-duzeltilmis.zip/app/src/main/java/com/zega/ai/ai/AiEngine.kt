package com.zega.ai.ai

import com.zega.ai.data.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Modular AI backend contract. Engines (local GGUF / llama.cpp via JNI, or a future
 * cloud API) implement this interface and are returned by [EngineRegistry].
 */
interface AiEngine {
    val id: String

    /** Streams the assistant reply token by token. Throws [EngineUnavailable] if it cannot run. */
    fun generate(history: List<ChatMessage>): Flow<String>
}

class EngineUnavailable(val code: String) : Exception(code)

/** Fallback engine used when no local engine is installed: it never invents an answer. */
object NoModelEngine : AiEngine {
    override val id: String = "none"

    override fun generate(history: List<ChatMessage>): Flow<String> = flow {
        throw EngineUnavailable("NO_MODEL")
    }
}

object EngineRegistry {
    @Volatile
    private var local: AiEngine? = null

    fun install(engine: AiEngine) {
        local = engine
    }

    fun active(): AiEngine = local ?: NoModelEngine
}

package com.zega.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.zega.ai.ZegaViewModel

enum class Screen { CHAT, SETTINGS, THEME, LANGUAGE, MODEL, HISTORY, STORAGE, VOICE, ABOUT, ONLINE_AI }

private fun parentOf(s: Screen): Screen = when (s) {
    Screen.CHAT -> Screen.CHAT
    Screen.SETTINGS -> Screen.CHAT
    else -> Screen.SETTINGS
}

@Composable
fun ZegaNav(vm: ZegaViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }

    BackHandler(enabled = screen != Screen.CHAT) { screen = parentOf(screen) }

    when (screen) {
        Screen.CHAT -> ChatScreen(vm, onOpenSettings = { screen = Screen.SETTINGS })
        Screen.SETTINGS -> SettingsHome(onBack = { screen = Screen.CHAT }, onOpen = { screen = it })
        Screen.THEME -> ThemeScreen(vm, onBack = { screen = Screen.SETTINGS })
        Screen.LANGUAGE -> LanguageScreen(vm, onBack = { screen = Screen.SETTINGS })
        Screen.MODEL -> ModelScreen(vm, onBack = { screen = Screen.SETTINGS })
        Screen.HISTORY -> HistoryScreen(vm, onBack = { screen = Screen.SETTINGS })
        Screen.STORAGE -> StorageScreen(vm, onBack = { screen = Screen.SETTINGS })
        Screen.VOICE -> VoiceScreen(onBack = { screen = Screen.SETTINGS })
        Screen.ABOUT -> AboutScreen(onBack = { screen = Screen.SETTINGS })
        Screen.ONLINE_AI -> OnlineAiSettingsScreen(vm, onBack = { screen = Screen.SETTINGS })
    }
}

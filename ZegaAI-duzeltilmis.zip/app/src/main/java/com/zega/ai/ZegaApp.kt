package com.zega.ai

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.zega.ai.data.SettingsStore

class ZegaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val want = LocaleListCompat.forLanguageTags(SettingsStore(this).language)
        if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != want.toLanguageTags()) {
            AppCompatDelegate.setApplicationLocales(want)
        }
    }
}

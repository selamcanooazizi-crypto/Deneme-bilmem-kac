package com.zega.ai.ai;
public class LlamaBridge {
  public native String load(String path, int nCtx, int nThreads);
  public native void unload();
  public native void stop();
  public native String generate(String[] roles, String[] contents, int maxNew, TokenCallback cb);
}
